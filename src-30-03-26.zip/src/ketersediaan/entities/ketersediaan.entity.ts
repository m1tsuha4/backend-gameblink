export class Ketersediaan {}
